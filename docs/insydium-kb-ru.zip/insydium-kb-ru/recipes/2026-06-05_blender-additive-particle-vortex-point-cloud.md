# Аддитивный вихрь частиц, рендер как point cloud (nxEmitter Disc Edge Only, nxTurbulence, nxRotate + Sphere falloff, экспорт Point Cloud)

- Источник: NeXus for Blender Official Training — Particle Vortex — https://www.youtube.com/watch?v=SLUkMBqGfZg (2026-06-05)
- Хост / поколение: Blender (NeXus for Blender, G3 nx-объекты в NeXus Hierarchy, N-панель); рендер в Cycles (GPU) или Eevee через точки Geometry Nodes
- Задача: миллионы крошечных светящихся частиц вылетают из кольца и закручиваются в молочный вихрь, похожий на туманность, с раскалённо-белыми пересечениями.

## Шаги
1. Панель NeXus ▸ Hierarchy ▸ **+ nxEmitter** (по умолчанию квадрат, стреляет по +Y); удалите плоскость пола. [▶ 0:48](https://youtu.be/SLUkMBqGfZg?t=48)
2. Эмиттер: Shape **Disc**, включите **Edge Only** (тонкая линия эмиссии = более мелкая детализация), Angle **90°**, чтобы частицы вылетали перпендикулярно краю. [▶ 1:13](https://youtu.be/SLUkMBqGfZg?t=73)
3. Birth Rate **100,000/s** на время настройки; снимите **Full Lifespan**, Lifespan **130 F**, Variation **30 F** (плавное, органичное отмирание). [▶ 2:08](https://youtu.be/SLUkMBqGfZg?t=128)
4. Вкладка Display: размер отрисовки 3 → **1** (это только размер точки во вьюпорте, не радиус в симуляции); для этого лука держите его маленьким. [▶ 3:56](https://youtu.be/SLUkMBqGfZg?t=236)
5. **+ nxTurbulence**: один слой нойза по умолчанию (собственный нойз INSYDIUM типа Voronoise; доступны и другие типы нойза, и слои с блендингом). Strength **7**, Scale **100%** (20% = очень мелко, больше = крупные завихрения), поднимите Frequency для более живого движения. [▶ 5:21](https://youtu.be/SLUkMBqGfZg?t=321)
6. **Axis Direction Scale** в nxTurbulence: Y **0** полностью сплющивает симуляцию; **0.3** оставляет немного глубины и добавляет пересечений (аддитивные прожилки получаются лучше). [▶ 5:57](https://youtu.be/SLUkMBqGfZg?t=357)
7. **+ nxRotate**: сначала Rotate Speed 75°, потом **110°**. [▶ 9:40](https://youtu.be/SLUkMBqGfZg?t=580)
8. nxRotate ▸ вкладка Falloff ▸ **Create/Add** → переключите Box на **Sphere**, увеличьте, Offset ≈ **−2** для длинного перехода — сильное вращение у кольца рождения, а дальше только турбулентность. [▶ 9:37](https://youtu.be/SLUkMBqGfZg?t=577)
9. Эмиттер ▸ **вкладка Export ▸ Point Cloud** (достаточно Basic data = position); отключите Show Particles в Display. [▶ 11:03](https://youtu.be/SLUkMBqGfZg?t=663)
10. Point cloud появляется под эмиттером в Outliner с автоматическим деревом Geometry Nodes (Named Attribute radius → points). Разорвите связь radius и вручную задайте Radius **0.003**. [▶ 12:55](https://youtu.be/SLUkMBqGfZg?t=775)
11. Birth Rate → **1,000,000/s** (≈4–5 M живых частиц, когда они начинают умирать). [▶ 13:59](https://youtu.be/SLUkMBqGfZg?t=839)
12. GN: нода **Set Material**. Шейдер: удалите Principled, **Emission** (зелёный, низкое значение) **+ Transparent BSDF** через **Mix Shader**, factor в основном в сторону прозрачности; Emission Strength 50 → **20–30**, чтобы пересечения были раскалённо-белыми. [▶ 15:09](https://youtu.be/SLUkMBqGfZg?t=909)
13. Рендер: **Cycles, GPU Compute** (на рендере инстансит настоящие сферы); Eevee показывает точки как квады, но тоже работает. [▶ 17:27](https://youtu.be/SLUkMBqGfZg?t=1047)
14. Ступеньки/полосы от сильных скоростей: настройки NeXus ▸ **Document ▸ Substeps 2** (поднимайте, пока ступеньки не исчезнут). [▶ 19:27](https://youtu.be/SLUkMBqGfZg?t=1167)

## Подводные камни
- Размер в Display ≠ радиус частицы; после разрыва связи Named Attribute радиус точки в GN независим.
- Перед рендером скройте хелперы модификаторов/falloff/эмиттера.

## Как сейчас (новые инструменты)
Те же объекты в NeXus 2026.1 beta (Blender + C4D). В 2026.1 добавлено 16 режимов nxFalloff (например, Torus/Cylinder подходят к кольцевому эмиттеру) и списки falloff для каждого слоя; nxWarp (Helix/Twist) — ещё один способ сформировать вихрь. Нода Particle Info (Blender) может передавать в шейдер данные каждой частицы.
