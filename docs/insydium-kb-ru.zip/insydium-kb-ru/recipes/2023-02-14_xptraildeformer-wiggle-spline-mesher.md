# Извивающиеся анимированные трейлы, превращённые в сужающиеся трубки (xpTrailDeformer formula/noise + xpSplineMesher)

- Источник: Top Tip Tuesday — xpTrailDeformer — https://www.youtube.com/watch?v=YaFY_HUvnug (2023-02-14)
- Хост / поколение: C4D; CPU X-Particles (xpEmitter, xpTrail, xpTrailDeformer, xpSplineMesher, turbulence); работает с любым сплайном C4D
- Задача: органичное волнистое движение трейлов и быстрая геометрия для рендера из трейлов. (Первый выпуск Top Tip Tuesday.)

## Исходная сцена
Сферический эмиттер выстреливает частицы; **xpTrail** генерирует прямые трейлы.

## Шаги
1. X-Particles ▸ Utilities ▸ **xpTrailDeformer**; сделайте его **дочерним к xpTrail** (как любой деформер) → анимированное синусоидальное покачивание по Y из **Formula** по умолчанию. [▶ 1:06](https://youtu.be/YaFY_HUvnug?t=66)
2. Голова трейла должна оставаться на месте: кривая **Strength along spline** (хвост → конец у частицы); опустите узел на конце у частицы до 0, чтобы трейлы не отрывались от своих частиц. [▶ 1:45](https://youtu.be/YaFY_HUvnug?t=105)
3. Менее регулярное движение: удалите формулу; вкладка **Shader** ▸ Y ▸ C4D **Noise**, поднимите **Mix**; у noise **Global Scale ~3000** + **Animation Speed**, чтобы он менялся во времени; затем снизьте Mix до едва заметного. [▶ 3:03](https://youtu.be/YaFY_HUvnug?t=183)
4. Включите в сцене модификатор turbulence для дополнительного движения.
5. Generators ▸ **xpSplineMesher**; привяжите xpTrail → простая геометрия вокруг каждого трейла. **Subdivisions** 1–2 → круглые трубки. [▶ 4:06](https://youtu.be/YaFY_HUvnug?t=246)
6. Сужение: откройте кривую **Size** (начало трейла → частица) и сделайте кончик тонким, а ближе к частице — толще. Спрячьте трейл. [▶ 4:33](https://youtu.be/YaFY_HUvnug?t=273)
7. Больше Mix у деформера = больше извивов и в мешах.

## Как сейчас (новые инструменты)
nxWarp (бета 2026.1; Noise / Wind gust wave / Helix, режим Deform) умеет деформировать частицы и меши; трейлы/меширование — через nxTrail / nxMesher.
