# Коллизии частиц между собой с импульсными «световыми» выбросами (nxConstraints Collisions + subframe steps)

- Источник: Top Tip Tuesday — Particle Collisions — https://www.youtube.com/watch?v=0JdFAE_dopk (2025-05-13)
- Хост / поколение: C4D; NeXus внутри X-Particles (слой nxConstraints Collisions, nxGravity) + CPU-тег xpCollider; Redshift (черепа как custom object)
- Задача: резервуар с крупными шарами, которые перемешиваются импульсами мелких светящихся частиц — остаточное движение как у жидкости, рендер инстансами черепов.

## Исходная сцена
Куб (отображение wireframe) с **xpCollider, Normals Inside**, bounce/friction 0. **nxGravity 500**. Основной эмиттер: Rate, **80 кадров, 100/кадр, speed 150, radius 5, variation 4**.

## Шаги
1. Основной эмиттер ▸ **No Intersection**, radius **12** (> самой большой частицы) — перекрывающиеся при рождении частицы убиваются, без «выстрелов». Позже чуть уменьшите для большего количества частиц. [▶ 1:27](https://youtu.be/0JdFAE_dopk?t=87)
2. Слой **nxConstraints ▸ Collisions**. С настройками по умолчанию всё схлопывается → **Iterations 10**. [▶ 2:14](https://youtu.be/0JdFAE_dopk?t=134)
3. Перекрытия ещё есть: Ctrl+D ▸ **X-Particles ▸ Subframe Steps 3** → чистые коллизии (быстрым частицам и сильной гравитации нужны подкадры). [▶ 3:25](https://youtu.be/0JdFAE_dopk?t=205)
4. Эмиттер «света»: круг с тегом C4D **Vibrate** (позиция X/Y); эмиссия **Pulse** — 4 кадра каждые 40, **старт F150, конец F400**, **500/кадр**, life **50 ±10**, **radius 1, variation 1**. [▶ 5:34](https://youtu.be/0JdFAE_dopk?t=334)
5. Оба эмиттера в одних и тех же constraints → импульсы пробиваются сквозь массу шаров. [▶ 6:07](https://youtu.be/0JdFAE_dopk?t=367)
6. Рендер: эмиттеры инстансируют **череп как custom object** (работает, потому что он примерно сферический); мелким частицам — светящийся материал. [▶ 7:04](https://youtu.be/0JdFAE_dopk?t=424)

## Подводные камни
Если потом добавить частиц, может снова понадобиться больше итераций/подкадров.

## Как сейчас (новые инструменты)
NeXus 2026: отдельные объекты **nxPPCollisions** и **nxCollider** заменяют слой Collisions / тег xpCollider; **nxSpawn** из беты 2026.1 (Rate/Burst/Pulse) может генерировать импульсы.
