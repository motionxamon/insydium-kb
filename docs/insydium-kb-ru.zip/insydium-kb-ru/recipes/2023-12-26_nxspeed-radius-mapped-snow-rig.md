# Естественный падающий снег (ограничение nxSpeed, замапленное на радиус + второй nxTurbulence Curl с Blend, замапленным на радиус)

- Источник: Top Tip Tuesday — NeXus Snow Rig — https://www.youtube.com/watch?v=RnIGtMwTpLg (2023-12-26)
- Хост / поколение: C4D; G2 NeXus внутри X-Particles (xpEmitter + nxGravity, nxSpeed, nxTurbulence, nxKill) + CPU xpGenerator
- Задача: реалистичный парящий снег для VFX-плейтов или полностью 3D-сцен; мелкие снежинки падают быстрее, а часть подбрасывают порывы (подходит и как риг для пыли/летающих частиц).

## Исходная сцена
**xpEmitter** Rectangle 950 × 2000, **Rate 1000/s**, speed 0, **radius 0.9 cm ±0.5** (диапазон 0.4–1.4 cm). Extended Data: Use Rotation, вращение при рождении Random, **Simple Spin** с небольшими значениями (даёт кувыркание). Дефолтный **nxGravity**; домен **nxKill** удаляет частицы за пределами границ.

## Шаги
1. Сопротивление воздуха: **nxSpeed** в самом низу (после гравитации). Operation **Incremental → Acceleration**, экспоненциальное значение **0** (без ускорения), включи **Speed Limit 85 cm**. [▶ 1:50](https://youtu.be/RnIGtMwTpLg?t=110)
2. nxSpeed ▸ Mapping ▸ карта **Radius** → ограничение максимальной скорости. Диапазон **Min 0.4 / Max 1.4**. Кривая: мелкие снежинки на полных 85, крупные — гораздо ниже. [▶ 3:25](https://youtu.be/RnIGtMwTpLg?t=205)
3. Снежинки: три сплайна Flower в объектах **Extrude** как дочерние у **xpGenerator** (эмиттер подключён), режим для нескольких детей Random, тип клонов **Multi-Instances** ради скорости во viewport. (С Redshift/Octane/Cycles 4D лучше инстансить на этапе рендера.) [▶ 5:35](https://youtu.be/RnIGtMwTpLg?t=335)
4. Завихрения: **nxTurbulence** ниже nxSpeed, **Voronoi**, strength ~12 (потом чуть меньше), масштаб побольше, частота пониже. [▶ 6:16](https://youtu.be/RnIGtMwTpLg?t=376)
5. Подбрасывание порывами (ключевой шаг): продублируй турбулентность, тип **Curl**, strength **4**. В опциях Curl выключи **Add**, **Blend** оставь высоким (0 = без эффекта, около максимума перекрывает текущую скорость). [▶ 8:09](https://youtu.be/RnIGtMwTpLg?t=489)
6. Mapping ▸ карта **Radius**, категория Curl, параметр **Blend**, тот же диапазон 0.4–1.4; мелкие частицы получают полный blend, крупные — нулевой → лишь часть снежинок закручивается и уносится вверх. [▶ 8:30](https://youtu.be/RnIGtMwTpLg?t=510)
7. Рендер с DOF + motion blur. [▶ 9:09](https://youtu.be/RnIGtMwTpLg?t=549)

## Как сейчас (новые инструменты)
Слоёные **nxTurbulence/nxSpeed** в Fused 2025.4 позволяют держать обе турбулентности в одном объекте. В бете 2026.1 слой nxSpeed называется **Acceleration**, а **nxGenerator** / **nxEmitter** (G3) заменяют xp-объекты; ещё один вариант для порывов — волны **nxWind** через **nxWarp**.
