# Песок + вода в одной симуляции (nxFluids SPH Granular + тег nxFluids на эмиттере, stability через age)

- Источник: Top Tip Tuesday — Simulating Sand and Water — https://www.youtube.com/watch?v=JvAcrBQDDvw (2025-03-25)
- Хост / поколение: C4D; NeXus внутри X-Particles (nxFluids SPH, nxGravity, тег nxFluids, Mapping) + CPU-тег xpCollider на земле
- Задача: песочный тор, который держит форму сам, а потом рассыпается, когда в него бьёт струя воды.

## Исходная сцена
Плоскость земли с **xpCollider**; тор как источник объёма. Эмиттер песка: объём Object (тор), **Shot Hexagonal, radius 1.5**. Эмиттер воды: маленькая сфера, непрерывный Hexagonal, **radius 1.5**. nxGravity + nxFluids по умолчанию.

## Шаги
1. **nxFluids ▸ fluid type Granular**. Поднять **Substeps до 20** (без этого granular не слипается). [▶ 0:00](https://youtu.be/JvAcrBQDDvw?t=0)
2. Настройки Granular: **Friction ~79–80%** (с дефолтными 3% не устоит), **Stability 20** (при 5 сразу трескается; при 20 стоит монолитом). [▶ 4:57](https://youtu.be/JvAcrBQDDvw?t=297)
3. Эмиттер воды ▸ Tags ▸ INSYDIUM ▸ **тег nxFluids**: переопределить тип на **Liquid**, добавить немного Surface Tension → он игнорирует настройку Granular в солвере. [▶ 3:35](https://youtu.be/JvAcrBQDDvw?t=215)
4. Убираем «взрыв» давления у источника воды: nxFluids ▸ проверять плотность новых частиц, **убивать, если при рождении плотность выше 105%**. [▶ 4:01](https://youtu.be/JvAcrBQDDvw?t=241)
5. Делаем песок разрушаемым при ударе: nxFluids ▸ **Mapping ▸ Age map**, Category **SPH**, Parameter **Stability**, диапазон **0–30 frames**; кривая: полная стабильность при рождении, падение до ~0 к ~20-му кадру. Опустите кривую ещё ниже — будет сильнее осыпаться. [▶ 5:24](https://youtu.be/JvAcrBQDDvw?t=324)

## Подводные камни
- Для смешивания в SPH нужен **одинаковый радиус частиц** на всех эмиттерах.
- Одни лишь высокие friction/stability делают песок неуязвимым для воды — разрушаться ему позволяет именно маппинг по age.

## Как сейчас (новые инструменты)
В 2026.1 beta **nxMPM** — мультиматериальный (жидкость + песок в одном солвере; Mixer может менять материал по age/speed/damage), а у **nxMaterial** есть пресет «Sand wet» — более физичный путь к мокрому песку. В стабильном Fused 2025.4 — этот сетап SPH Granular + тег.
