# Аддитивно светящиеся частицы в Octane (1 M против 10 M частиц)

- Источник: Top Tip Tuesday — Octane Particle Glow — https://www.youtube.com/watch?v=AjAFehv2dRs (2026-07-07)
- Хост / поколение: C4D, закэшированная advection-симуляция nxExplosiaFX + Octane
- Задача: дымчатый, самосветящийся «аддитивный» вид частиц.

## Шаги
1. Эмиттеры (закэшированная advection-симуляция, версии на 1 M и 10 M) → **Octane Object tag** → Particle Rendering → включите **Geometry**, подключите крошечную сферу-инстанс: **Hexahedron type, мало сегментов, radius 0.05** (1 M) / **0.015** (10 M). [▶ 0:44](https://youtu.be/AjAFehv2dRs?t=44)
2. Чёрное окружение: **Octane Texture Environment**, цвет чёрный → в сцене нет света. [▶ 1:39](https://youtu.be/AjAFehv2dRs?t=99)
3. **Universal Material** на сфере-инстансе: Specular 0; **Emission** = Texture Emission (Surface Brightness вкл.) с синей цветовой текстурой; **Opacity** = средне-серый (0.5) → перекрытия складываются и становятся ярче. [▶ 4:30](https://youtu.be/AjAFehv2dRs?t=270)
4. Настройки рендера: Direct Lighting вполне подходит; Max Samples ~3000; **Adaptive Sampling** вкл. (min 512, noise threshold 0.005). С DOF + denoise включите **Static Noise**, чтобы не было мерцания. [▶ 6:16](https://youtu.be/AjAFehv2dRs?t=376)
5. Больше частиц + меньше инстансы = более гладкие завитки. 1 M выглядит зернисто (это не шум рендера — просто мало частиц); 10 M с радиусом 0.015 — гладко. Денойз может сымитировать, но никогда не сравнится с большим количеством частиц. (Демо: 720p, 70 кадров ≈ 17 мин.) [▶ 7:51](https://youtu.be/AjAFehv2dRs?t=471)

## Эмпирическое правило
Каждые ×10 к числу частиц → уменьшайте радиус инстанса примерно в 3 раза, иначе горячие точки пересвечиваются.
