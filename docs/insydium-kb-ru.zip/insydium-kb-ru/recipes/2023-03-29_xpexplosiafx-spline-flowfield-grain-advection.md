# Дымовой взрыв по сплайнам, который адвектит живые гранулы (xpExplosiaFX Advection + xpFlowField Along Spline + falloff эмиттера)

- Источник: Maintenance Training — XP Countdown - Series 2 - xpExplosiaFX Advection 01 — https://www.youtube.com/watch?v=OKRG2FUtXjc (2023-03-29)
- Хост / поколение: C4D; всё на **CPU (G1)**: xpExplosiaFX + Source tag, xpFlowField, гранулы xpFluidFX granular из прошлого эпизода (живые, не в кэше)
- Задача: цифру «2» из гранулярных частиц разносит цветной дымовой выброс, клубы которого дугами по сплайнам летят вперёд к «1».

## Исходная сцена
- Сцену с гранулами сохраняем как новую сцену/папку (со своей папкой для cache); гранулы должны оставаться **живыми**, иначе их не адвектить. Таймлайн 300 F; «2» хорошо читается к ~F70, поэтому взрыв стартует около F75–80.

## Шаги
1. **Меш-источник**: копия коллайдера «2» без тега коллайдера, у MoText крышки **None** (только боковины). Быстро получить один редактируемый меш: положить в объект **Connect** и нажать **C**. [▶ 5:35](https://youtu.be/OKRG2FUtXjc?t=335)
2. Новая **xpSystem** («System EFX», свой цвет иконки); форма эмиттера **Object** → меш-источник, Emit From **Polygon Area**, **Invert** направления по нормали (у MoText нормали смотрят внутрь). [▶ 7:45](https://youtu.be/OKRG2FUtXjc?t=465)
3. Оставляем режим **Rate** и используем у эмиттера **Object ▸ Falloff ▸ Box**: тонкий бокс, эмиссия только там, где он пересекает меш. Ключи по Y с **F76 → F85**, ключи F-curve делаем **linear** = быстрый «проходящий» выброс. [▶ 10:37](https://youtu.be/OKRG2FUtXjc?t=637)
4. Домен **xpExplosiaFX** (с запасом под дугу к «1»); на этапе прикидки **Voxel Size 6**. На эмиттер — **xpExplosiaFX Source tag**; в эмиттере Extended Data ▸ Physical **Fuel 1**. [▶ 19:03](https://youtu.be/OKRG2FUtXjc?t=1143)
5. Display: режим **Grid** (или Slices ~80, Resolution ~150) — так дым читается лучше. [▶ 20:09](https://youtu.be/OKRG2FUtXjc?t=1209)
6. Вкладка Simulation: **gravity убрана** (без всплытия — стилизация, дым идёт по траекториям). В Source tag **Velocity 300%**, чтобы дым двигался вместе с частицами, а не зависал. [▶ 45:44](https://youtu.be/OKRG2FUtXjc?t=2744)
7. Траектории: во виде Right (орто) рисуем Pen одну дугу **Bezier**; **Cloner Radial, 9 клонов**, маленький радиус, чтобы сходились; **Connect** + **C** → один объект-сплайн («splines»). [▶ 29:59](https://youtu.be/OKRG2FUtXjc?t=1799)
8. **xpFlowField**: flow **Along Spline**, линкуем splines, **falloff выкл.**, cell size 40 → ~17–18 см, **Strength ~40** (по умолчанию слишком слабо, частицы не долетают до «1»). [▶ 32:05](https://youtu.be/OKRG2FUtXjc?t=1925)
9. Настройка эмиттера (Display **Circles**, чтобы видеть радиус): Lifespan ~60 F + вариация; Speed **130**, вариация **30**; Birth Rate 1000 → **300**; **No Intersection** вкл. (без сгустков с удвоенным топливом); Radius **8** (с вариацией) при таком вокселе — когда воксели станут мельче, снизить до ~4–5. [▶ 33:47](https://youtu.be/OKRG2FUtXjc?t=2027)
10. **xpExplosiaFX ▸ Modifiers**: добавляем xpFlowField, чтобы и сам дым толкало вдоль сплайнов. Траектории можно поджать, масштабируя точки сплайна внутрь. [▶ 38:54](https://youtu.be/OKRG2FUtXjc?t=2334)
11. Изоляция: System EFX ▸ **Only Modifiers in Same System** вкл. Эмиттер гранул ▸ Modifiers ▸ **Exclude** — xpFlowField (адвекцию от EFX он видеть должен). [▶ 42:18](https://youtu.be/OKRG2FUtXjc?t=2538)
12. **xpExplosiaFX ▸ Advection ▸ Advect Particles**: только **Velocity 100**, остальные каналы (smoke, burn, temperature, color, UV) — 0. [▶ 47:04](https://youtu.be/OKRG2FUtXjc?t=2824)
13. Ключи на Advection Velocity: **0** до старта взрыва (~F76–77), затем **100** через несколько кадров. [▶ 47:04](https://youtu.be/OKRG2FUtXjc?t=2824)
14. Ключом выключаем чекбокс **Enabled у xpFluidFX** ровно в момент старта взрыва (~F77–78) — два солвера скоростей на одних частицах конфликтуют. [▶ 53:37](https://youtu.be/OKRG2FUtXjc?t=3217)
15. Эмиттер EFX ▸ Modifiers ▸ **Exclude** — xpExplosiaFX, иначе частицы-источники адвектятся собственным дымом и перестают следовать flow field. [▶ 55:53](https://youtu.be/OKRG2FUtXjc?t=3353)

## Подводные камни
- **Adaptive Bounds** стартует с бокса, который замораживает адвектируемые гранулы внутри ещё до появления дыма — выключение помогает, но считается медленно; решение — ключ Velocity 0.
- Две системы по умолчанию влияют друг на друга: каждый эмиттер видит все модификаторы сцены, если их не изолировать (шаг 11).

## Как сейчас (новые инструменты)
Fused 2025.4: дым на GPU **nxExplosiaFX** (источники перечисляются во вкладке Sources); гранулы — nxFluids SPH Granular или песок **nxMPM** (бета 2026.1). Для режиссуры траекторий в бете 2026.1 **nxWarp** (Path / Flow) гнёт и частицы, и дым; в Fused 2025.4 частицы ведёт nxFollowGeo с несколькими сплайнами. В whats-new не описано, чтобы GPU-дым адвектил другие частицы, так что для такой передачи эталоном остаётся CPU-адвекция выше.
