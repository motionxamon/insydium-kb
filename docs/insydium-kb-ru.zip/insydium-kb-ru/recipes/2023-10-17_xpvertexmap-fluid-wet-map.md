# Динамическая карта намокания там, где жидкость бьёт в стену (слой X-Particles в xpVertexMap, Fade then Add)

- Источник: Top Tip Tuesday — nxFluids Wet Maps — https://www.youtube.com/watch?v=d0Rps3gG9JI (2023-10-17)
- Хост / поколение: C4D; G2 nxFluids SPH + утилита **CPU xpVertexMap** (работает и с CPU-флюидами)
- Задача: vertex map, которая рисует влажность там, где жидкость касается геометрии, и медленно высыхает, — для мокрого материала на рендере.

## Исходная сцена
Цилиндрический эмиттер; **nxGravity 600 cm**; **nxFluids SPH**, substeps **5**, **Check Density** вкл. (без взрывных рождений). Низкополигональный куб-стена + плоскость пола как коллайдеры (быстрые GPU-коллизии).

## Шаги
1. Продублируйте стену: низкополигональный коллайдер скройте (и сделайте нерендеримым); на копии удалите тег коллайдера и поднимите сегменты (**X 90 / height 40**). [▶ 2:08](https://youtu.be/d0Rps3gG9JI?t=128)
2. Utilities ▸ **xpVertexMap** в самом низу, object = плотная копия. [▶ 1:24](https://youtu.be/d0Rps3gG9JI?t=84)
3. Удалите слой **Polygons** по умолчанию; добавьте слой **X-Particles**, object = эмиттер. [▶ 2:45](https://youtu.be/d0Rps3gG9JI?t=165)
4. Радиус слоя **25 → 5 cm** (на этом расстоянии вес затухает).
5. Вкладка Effects: добавьте **smoothing**. [▶ 3:58](https://youtu.be/d0Rps3gG9JI?t=238)
6. Layers ▸ Blend **Normal → Fade then Add** и поднимите fade → влажность накапливается и со временем высыхает. [▶ 4:43](https://youtu.be/d0Rps3gG9JI?t=283)
7. Используйте vertex map в материале стены (маска мокрого/глянцевого). [▶ 5:02](https://youtu.be/d0Rps3gG9JI?t=302)

## Подводные камни
- Рисуйте на плотной рендер-копии, а не на низкополигональном коллайдере.

## Как сейчас (новые инструменты)
2026.1 beta: режим **Wet nxFalloff**, а в C4D **nxFalloffMap** запекает falloff в теги vertex map / vertex color (см. рецепт 2026-04-07 soot damage vertex map).
