# Плавающий / тонущий объект в жидкости NeXus (тег xpDynamics + плотность в nxFluids tag на эмиттер)

- Источник: Top Tip Tuesday — nxFluid Dynamic Objects — https://www.youtube.com/watch?v=3cWjs6bgjBI (2023-11-07)
- Хост / поколение: C4D; G2 nxFluids SPH + **CPU-тег xpDynamics** (работает и с CPU-жидкостями X-Particles)
- Задача: спасательный круг, который покачивается на поверхности бурной воды (или тонет), двигаясь как твёрдый объект.

## Исходная сцена
Куб с тегом **xpCollider**, Normal **Inside** (удерживает воду); **xpEmitter** с эмиссией Box, **Shot – Hexagonal**, радиус **2 cm**; гравитация по умолчанию; **nxTurbulence**; **nxFluids SPH**, substeps **3 → 4**.

## Шаги
1. На торе: Tags ▸ X-Particles ▸ **xpDynamics** — рождает динамические частицы на каждой вершине. [▶ 2:20](https://youtu.be/3cWjs6bgjBI?t=140)
2. Перед проигрыванием ставим в теге **Radius = 2 cm** (как у воды) — SPH нужен один радиус для всех частиц, иначе сим становится нестабильным. [▶ 1:56](https://youtu.be/3cWjs6bgjBI?t=116)
3. **Update Points off** → никакой soft-body деформации, только позиция/вращение (твёрдое тело). [▶ 2:59](https://youtu.be/3cWjs6bgjBI?t=179)
4. Эмиттер воды ▸ **nxFluids tag** (настройки жидкости на уровне эмиттера), оставляем по умолчанию. [▶ 3:51](https://youtu.be/3cWjs6bgjBI?t=231)
5. xpDynamics ▸ Properties ▸ **Add Emitter** → переименовываем в "emitter dynamic", Display ▸ Draw Emitter выключаем, прячем его частицы; Ctrl-перетаскиванием копируем на него тег nxFluids. [▶ 4:41](https://youtu.be/3cWjs6bgjBI?t=281)
6. В его теге nxFluids **Density 100** → круг плавает; **3000** — тонет; **200** — всплывает обратно. [▶ 6:02](https://youtu.be/3cWjs6bgjBI?t=362)
7. Исключаем **nxTurbulence** в списке Modifiers динамического эмиттера, чтобы перемешивалась только вода и уже она толкала круг. [▶ 5:51](https://youtu.be/3cWjs6bgjBI?t=351)

## Подводные камни
- Разные радиусы у воды и динамических частиц ломают SPH.

## Как сейчас (новые инструменты)
NeXus 2026.1 beta: **nxOcean** поддерживает плавающие объекты, а **nxMPM** (elastic/metal) или **nxPin** + nxConstraints дают твёрдые тела на GPU; GPU rigid bodies анонсированы, но ещё не вышли (Nov 2026).
