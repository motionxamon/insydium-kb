# Выбор режима инстансинга частиц в Redshift (Redshift Object tag ▸ Particles: points, quads, spheres, custom objects)

- Источник: Bite-Sized — Redshift Particle Instances — https://www.youtube.com/watch?v=qOTF_oVXI1c (2025-09-25)
- Хост / поколение: C4D + **Redshift**; обычный **xpEmitter** (разный радиус, лёгкое вращение), без модификаторов
- Задача: понять, что рендерит каждый режим инстансинга Redshift и когда какой использовать.

## Шаги
1. Emitter ▸ Tags ▸ Render tags ▸ **Redshift Object tag** → появляется вкладка **Particles**. Mode по умолчанию **Disabled** (ничего не рендерится). [▶ 0:35](https://youtu.be/qOTF_oVXI1c?t=35)
2. **Point instances**: диски, повёрнутые к камере. Очень лёгкие по VRAM/времени → лучше всего для миллионов мелких частиц с аддитивными материалами. [▶ 10:16](https://youtu.be/qOTF_oVXI1c?t=616)
3. **Quad instances**: квады, повёрнутые к камере; вращение частиц игнорируют. [▶ 2:34](https://youtu.be/qOTF_oVXI1c?t=154)
4. **Optimized spheres**: трюк на уровне шейдинга, а не настоящий объём — пересечения шейдятся неправильно, а **depth/scatter** в transmission ни на что не влияют. [▶ 3:37](https://youtu.be/qOTF_oVXI1c?t=217)
5. **Sphere instances**: настоящая геометрия сфер → правильные пересечения и полупрозрачное стекло (Transmission на полную, scatter color, **Depth ~25%** и выше). Лучший выбор для обычных сфер. [▶ 5:35](https://youtu.be/qOTF_oVXI1c?t=335)
6. **Custom objects**: любая геометрия сцены инстансится на каждую частицу с учётом вращения. Для масштаба: примитив Sphere **radius 1 cm** = точно радиус частицы. [▶ 6:58](https://youtu.be/qOTF_oVXI1c?t=418)
7. Несколько custom objects (например, три сферы с разными материалами) назначаются **последовательно по ID частицы** (1,2,3,1…), либо поставьте Distribution в **Random**. [▶ 8:44](https://youtu.be/qOTF_oVXI1c?t=524)
8. Cube: используйте **2×2×2 cm** (размер частицы — это радиус, а размер куба — полная длина ребра), чтобы совпало с viewport. [▶ 9:57](https://youtu.be/qOTF_oVXI1c?t=597)

## Подводные камни
- В режиме Custom objects материал должен висеть на инстансируемом объекте, а не на emitter (иначе серый рендер).
