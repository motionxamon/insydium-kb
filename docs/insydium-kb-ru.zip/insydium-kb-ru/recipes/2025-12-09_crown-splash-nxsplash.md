# Арт-директорский всплеск-корона (FLIP + хэндлы nxSplash)

- Источник: Top Tip Tuesday — Crown Splash — https://www.youtube.com/watch?v=S4Bfw_hb9AI (2025-12-09)
- Хост / поколение: C4D, Fused 2025.4 (новый nxSplash, FLIP, nxMesher)
- Задача: стилизованная корона с N ровными пиками и чистыми тонкими плёнками.

## Шаги
1. **nxGravity 700**; **nxFluids FLIP** (домен). Эмиттер: **Torus** inner 8 / outer 12 cm у самого пола, **Shot** за 10 кадров, 5 000/frame (→ 15 000/frame в финале), speed 0, цвет по скорости (max 350). [▶ 0:22](https://youtu.be/S4Bfw_hb9AI?t=22)
2. **nxSplash**: в орто-видах поставьте его **Bottom Radius по середине тора** (10 cm). **Duration 5 F** (30 по умолчанию — слишком резко), Strength ~75%. [▶ 2:24](https://youtu.be/S4Bfw_hb9AI?t=144)
3. Точность для плёнок: **Voxel 4** (по умолчанию 10), Solver **Min/Max substeps 2/4**, **radius 1** у частиц (держите соотношение voxel:radius по умолчанию ~10:3). [▶ 3:48](https://youtu.be/S4Bfw_hb9AI?t=228)
4. Форма: уменьшите **Top Radius** → конус сильнее вверх. **Handle Num = 2 × пиков** (14 для 7 пиков), опустите каждый второй хэндл силы → пики/впадины. Хэндлы верхнего/нижнего радиуса + касательные Bezier для неровных форм. Дублируйте splash, чтобы перебирать варианты на лукдеве. [▶ 5:12](https://youtu.be/S4Bfw_hb9AI?t=312)
5. Плёнки рвутся → больше частиц (150 k всего), **Surface Tension ~1%** (10% = капли; при высокой точности много не нужно), по желанию **Weak Particle Repulsion** для ровных плёнок. [▶ 9:09](https://youtu.be/S4Bfw_hb9AI?t=549)
6. **nxMesher** radius 1.3, Polygon Size 1, **Zhu-Bridson** (гладко без слоёв сглаживания) → материал воды. [▶ 10:12](https://youtu.be/S4Bfw_hb9AI?t=612)
