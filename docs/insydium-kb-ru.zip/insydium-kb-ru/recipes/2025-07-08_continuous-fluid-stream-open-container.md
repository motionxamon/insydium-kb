# Бесконечная река / поток жидкости (открытый с одной стороны контейнер + эмиттер подпитки + nxKill)

- Источник: Top Tip Tuesday — Fluid Streams — https://www.youtube.com/watch?v=q8Crdpa1XUw (2025-07-08)
- Хост / поколение: NeXus nxFluids SPH, nxGravity, nxKill + xpCollider
- Задача: постоянный однонаправленный поток через камни со светящимися частицами-трассерами.

## Шаги
1. Куб «fluid container» чуть больше камней; дублируйте его как «fluid kill» (немного крупнее, скрытый). [▶ 0:35](https://youtu.be/q8Crdpa1XUw?t=35)
2. Контейнер: **xpCollider** bounce/friction 0, Normals **Inside**; сделайте редактируемым и **удалите грань на выходе**. [▶ 1:31](https://youtu.be/q8Crdpa1XUw?t=91)
3. Базовый эмиттер: бокс ≈ по площади контейнера, высотой 35 cm у дна; **Shot, Hexagonal**, speed 0, radius 3. [▶ 2:51](https://youtu.be/q8Crdpa1XUw?t=171)
4. **nxGravity 300**, **nxFluids SPH** substeps 4. **Наклоните гравитацию** к +Z, чтобы толкать поток. [▶ 3:20](https://youtu.be/q8Crdpa1XUw?t=200)
5. **nxKill ▸ Object**: убивать вне объёма «fluid kill» → вылетевшие частицы больше не тратят время. [▶ 3:50](https://youtu.be/q8Crdpa1XUw?t=230)
6. Подпитка: тонкий широкий бокс-эмиттер в дальнем конце, Hexagonal непрерывно, spacing **200%**, speed 0; расширьте его, если уровень падает. [▶ 8:02](https://youtu.be/q8Crdpa1XUw?t=482)
7. Display: Gradient by Parameter ← Speed (auto) для наглядного превью. [▶ 4:29](https://youtu.be/q8Crdpa1XUw?t=269)
8. Светящиеся трассеры: третий эмиттер из объединения сфер вокруг камней, Shot Hex на кадре 6, белые — они катаются по течениям. [▶ 7:42](https://youtu.be/q8Crdpa1XUw?t=462)

## Подводные камни
Для SPH **у всех эмиттеров должен быть строго одинаковый radius**.

## Как сейчас (новые инструменты)
FLIP/APIC (Fused 2025.4) для больших рек; в бете 2026.1 — **nxOcean** для открытой воды.
