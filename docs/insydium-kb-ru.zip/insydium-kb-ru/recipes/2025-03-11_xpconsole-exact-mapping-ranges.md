# Точные диапазоны mapping по живым данным частиц (min/max из xpConsole → nxColor / Mapping)

- Источник: Top Tip Tuesday — xpConsole — https://www.youtube.com/watch?v=Q0gZAMr9MN0 (2025-03-11)
- Хост / поколение: C4D; утилита X-Particles **xpConsole**, инспектирующая NeXus G2 sim (nxTurbulence, nxDrag, nxColor)
- Задача: перестать угадывать значения Min/Max — считывать их с частиц.

## Исходная сцена
Лёгкая дымная симуляция: turbulence + drag; градиент **nxColor** по **Distance Travelled** — но красный край так и не появляется, потому что диапазон неверный.

## Шаги
1. X-Particles ▸ Utilities ▸ **xpConsole**: таблица данных по каждой частице на текущем кадре (по умолчанию: ID, Age). [▶ 1:19](https://youtu.be/Q0gZAMr9MN0?t=79)
2. Шорткат: Window ▸ Customization ▸ **Command Manager**, найдите xpConsole, перетащите иконку на палитру. [▶ 1:38](https://youtu.be/Q0gZAMr9MN0?t=98)
3. Data to Display ▸ добавьте канал **Distance**. **Двойной клик по любому значению** → Min/Max канала (≈652 в демо). [▶ 2:30](https://youtu.be/Q0gZAMr9MN0?t=150)
4. Поставьте Max в nxColor чуть ниже (620) → полный градиент, красные на самых дальних частицах. [▶ 2:58](https://youtu.be/Q0gZAMr9MN0?t=178)
5. То же для **Speed**: добавьте канал, двойной клик, поставьте Max чуть ниже показанного максимума. [▶ 3:33](https://youtu.be/Q0gZAMr9MN0?t=213)
6. Работает для любого Mapping: например, nxTurbulence ▸ Mapping ▸ Distance Travelled → Strength с точным диапазоном из консоли (0–633). [▶ 4:23](https://youtu.be/Q0gZAMr9MN0?t=263)

## Подводные камни
Значения покадровые — проверяйте на том кадре, где важен экстремум.

## Как сейчас (новые инструменты)
В NeXus for Blender 2026.0.1 добавили фильтр эмиттера в консоли, так что та же привычка «сначала посмотри, потом мапь» работает и там.
