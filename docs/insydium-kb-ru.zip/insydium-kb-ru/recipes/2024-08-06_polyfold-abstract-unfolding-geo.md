# Абстрактные разворачивающиеся полосы с толщиной и зубцами (MeshTools mtPolyFold + mtShellGen + mtInset + mtSubDivider)

- Источник: Top Tip Tuesday — PolyFold Abstract Geo — https://www.youtube.com/watch?v=V6yMgNIK5B8 (2024-08-06)
- Хост / поколение: C4D; процедурный стек **MeshTools** (mtPolyFold появился в Fused 2024.2); без частиц
- Задача: сплюснутый тор, который разворачивается/сворачивается спиральной волной, с толстой зубчатой сглаженной поверхностью.

## Исходная сцена
Редактируемый сплюснутый Torus с чистой квадовой сеткой (PolyFold нужны хорошие лупы; грязные/триангулированные меши разворачиваются плохо). Режим полигонов ▸ **Loop Selection (U~L)** — кольцо полигонов ▸ Select ▸ **Set Selection** (polygon selection tag).

## Шаги
1. Выделив тор, добавьте **mtPolyFold** с Alt (Alt = генератор становится родителем). По умолчанию: Distribution Random, 1 точка, 50 % unfold. [▶ 1:10](https://youtu.be/V6yMgNIK5B8?t=70)
2. Distribution **Selection** → перетащите polygon selection tag; направление Clockwise (или Anticlockwise). [▶ 1:50](https://youtu.be/V6yMgNIK5B8?t=110)
3. Ключи на unfold: **100 % на F0 → 0 % на F119**. [▶ 2:09](https://youtu.be/V6yMgNIK5B8?t=129)
4. **Variation ~4 %** смещает скорость складывания для каждой полосы → спираль. Верните Variation ключом в 0 на последнем ключе (и 4 % примерно на F80), чтобы форма аккуратно встала на место. [▶ 2:45](https://youtu.be/V6yMgNIK5B8?t=165)
5. Кривой шейдинг в состоянии покоя = несвязанные полигоны → **Advanced ▸ Optimize** сваривает их обратно. [▶ 3:31](https://youtu.be/V6yMgNIK5B8?t=211)
6. Уменьшите **Angle** складывания для более свободных завитков (тоже анимируется). [▶ 3:44](https://youtu.be/V6yMgNIK5B8?t=224)
7. С Alt добавьте **mtShellGen**, Thickness **2**. Его вкладка **Selections** ▸ **Caps** создаёт выделение внутренних полигонов. [▶ 4:37](https://youtu.be/V6yMgNIK5B8?t=277)
8. С Alt добавьте **mtInset**, ограниченный этим выделением caps; amount на полную + немного offset → выпуклые "зубцы" вдоль полос. [▶ 5:18](https://youtu.be/V6yMgNIK5B8?t=318)
9. С Alt добавьте сверху **mtSubDivider** для сглаживания.

## Подводные камни
- Каждый объект MeshTools ставится родителем предыдущего (Alt-клик), чтобы стек вычислялся по порядку.
