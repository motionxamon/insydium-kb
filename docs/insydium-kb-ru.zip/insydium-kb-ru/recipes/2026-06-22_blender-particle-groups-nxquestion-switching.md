# Запуск модификаторов переключением групп частиц (nxGroup, Groups Affected, nxQuestion Set Group)

- Источник: NeXus for Blender Quick Guide — Particle Groups — https://www.youtube.com/watch?v=P9O1SJhPeik (2026-06-22)
- Хост / поколение: Blender (NeXus for Blender, G3); nxEmitter, nxGroup, nxWind, nxGravity, nxColor, nxCollider, nxQuestion
- Задача: частицы лежат на Suzanne, при смене группы (по возрасту или движущимся falloff) их сдувает ветром, а пролетев некоторое расстояние, они падают под действием гравитации.

## Исходная сцена
Suzanne (Subdivision 2, применён, shade smooth). **nxEmitter** Shape Object = Suzanne, эмиссия с **Poly Area**, Shot на **100,000**, Speed 0. **nxWind** Mode **Von Karman** с небольшой вариацией силы, Heading повёрнут, чтобы дуло влево. **nxCollider**: слой с большой скрытой плоскостью (небольшие bounce + friction) + слой Suzanne (без bounce/friction).

## Шаги
1. Эмиттер ▸ вкладка **Groups** ▸ кнопка добавления группы (автоматически создаёт **nxGroup** и слой группы). Рождённые частицы теперь получают свойства частиц группы (по умолчанию зелёные, есть скорость) — поставьте у группы Speed 0. [▶ 3:21](https://youtu.be/P9O1SJhPeik?t=201)
2. Добавьте вторую группу (розовая, speed 0). Режим групп эмиттера **Random** делит частицы между ними. [▶ 5:29](https://youtu.be/P9O1SJhPeik?t=329)
3. Добавьте в имя каждой группы её **Group ID** (1, 2, 3…) — так проще писать условия дальше. [▶ 6:30](https://youtu.be/P9O1SJhPeik?t=390)
4. Любой модификатор ▸ **Groups Affected**: nxWind только на группу 2 (галочка = включить, минус = исключить/инвертировать). [▶ 7:12](https://youtu.be/P9O1SJhPeik?t=432)
5. Режим групп эмиттера **First Group Only** → все рождаются в группе 1 (ветер ничего не делает). [▶ 7:52](https://youtu.be/P9O1SJhPeik?t=472)
6. **nxQuestion** ▸ слой Question: категория Particle, **Age > 45** → дочерний **Action** (по умолчанию Set Color жёлтым для проверки) → переключите на **Set Group = group 2**. Размойте порог: **Age 55, variation 20**. [▶ 9:17](https://youtu.be/P9O1SJhPeik?t=557)
7. **nxColor** Gradient by Parameter (speed), подстройте min/max. [▶ 11:53](https://youtu.be/P9O1SJhPeik?t=713)
8. Тактильный вариант: категория условия **Field** со **Sphere falloff** (оранжевый = 1 → синий = 0); **Field > 0** → Set Group 2. Анимируйте falloff, чтобы "кистью" срывать частицы. [▶ 13:04](https://youtu.be/P9O1SJhPeik?t=784)
9. Третья группа + **nxGravity** с Groups Affected = group 3. Новое условие (используйте **Outdent**, чтобы оно не было дочерним): **Distance Travelled > 5 m, variation 1 m** → Set Group 3 (при проверке через цветовое действие отключите nxColor — он перекрывает цвет). [▶ 15:49](https://youtu.be/P9O1SJhPeik?t=949)
10. Добавьте группу 3 в Groups Affected ветра, чтобы падающие частицы продолжало гнать по полу. [▶ 17:11](https://youtu.be/P9O1SJhPeik?t=1031)

## Подводные камни
- Свойства частиц группы (цвет, скорость…) применяются **только при рождении**; nxQuestion Set Group меняет лишь ID группы.
- Новые слои условий автоматически вкладываются в выделенный — для независимого условия делайте outdent.

## Как сейчас (новые инструменты)
NeXus 2026.1 beta: у каждого слоя модификатора свой список Falloff и 16 режимов nxFalloff, так что простые эффекты "внутри сферы" работают без переключения групп; **Quill** (Blender) может набросать логику nxQuestion по запросу на обычном языке.
