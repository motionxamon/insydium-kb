# Отслаивание с поверхности, как у краски (группы nxInfectio + nxWind/nxTurbulence + nxConstraints Distance)

- Источник: Bite-Sized — Particle Peeling — https://www.youtube.com/watch?v=xGxf_IIIekY (2025-05-22)
- Хост / поколение: C4D; xpEmitter + GPU-модификаторы NeXus (nxInfectio, nxWind, nxTurbulence, nxConstraints)
- Задача: слой частиц на трубке отслаивается органичными тянущимися лоскутами от исходной точки.

## Шаги
1. **xpEmitter ▸ Object**: трубка, **Polygon Area**; Emission **Shot** в режиме **Simulate** (частицы есть уже на кадре 0), скорость 0, **100,000** частиц. Тег xpCollider на трубке. [▶ 0:44](https://youtu.be/xGxf_IIIekY?t=44)
2. **nxInfectio** ▸ **Add Seed Object**; сдвиньте seed к краю трубки — заражение расходится оттуда (по умолчанию — просто круговой рост). [▶ 1:26](https://youtu.be/xGxf_IIIekY?t=86)
3. Органичное распространение: эмиттер **Display ▸ Color Mode Shader ▸ Noise**, крупнее масштаб и больше контраста с обилием чёрного — заражение идёт по белому и обходит чёрное (подходит и для плесени). [▶ 2:06](https://youtu.be/xGxf_IIIekY?t=126)
4. Режим nxInfectio **Fixed Value → Use Groups**; через Ctrl добавьте группу инкубации и группу заражённых (группа 2 = те, что будут отслаиваться). [▶ 3:14](https://youtu.be/xGxf_IIIekY?t=194)
5. **nxWind**, направленный вверх, **Groups Affected = group 2** → сдувает только заражённые частицы. [▶ 4:04](https://youtu.be/xGxf_IIIekY?t=244)
6. Опционально **nxTurbulence** на группу 2, Voronoi, strength ~10, масштаб крупнее (само по себе даёт эффект распада). [▶ 4:26](https://youtu.be/xGxf_IIIekY?t=266)
7. Удержать вместе: **nxConstraints ▸ Distance** (не Birth — частицы уже существуют), только группа 2, **Connection Limit 50**, **Radius 250**; stiffness/breaking по умолчанию → тянущиеся отслаивающиеся лоскуты. [▶ 5:00](https://youtu.be/xGxf_IIIekY?t=300)

## Как сейчас (новые инструменты)
Для настоящей меш-оболочки, которая рвётся при отслаивании, — **nxDeformer** из NeXus 2026.1 (меш следует за частицами, с разрывами) или **nxPin**, чтобы закрепить незаражённые частицы; выборку делайте через falloff/группы в собственном списке falloff каждого слоя.
