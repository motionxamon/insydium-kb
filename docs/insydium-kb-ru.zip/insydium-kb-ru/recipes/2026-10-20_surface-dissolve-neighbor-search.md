# Распад объёма частиц снаружи внутрь (nxQuestion Neighbors → Set Group, силы с маппингом по скорости)

- Источник: Top Tip Tuesday — Surface Dissolve — https://www.youtube.com/watch?v=yOPa8oM_KXE (2026-10-20)
- Хост / поколение: Blender (NeXus for Blender); группы nxEmitter, nxQuestion, nxGravity, nxTurbulence, nxColor, nxConstraints Forces, nxCollider
- Задача: сплошная сфера из частиц слой за слоем осыпается с поверхности, песчинки скатываются и оседают на полу.

## Исходная сцена
- **nxEmitter** сфера radius 1.7, поднята вверх; Shot, random, **250,000** частиц, speed 0, radius **0.01**. Цвет при рождении чёрный.
- Plane + **nxCollider** (немного bounce, высокое трение, чуть-чуть scatter); плоскость скрыть.
- **nxGravity**, variation 1.

## Шаги
1. Эмиттер ▸ Groups: **Create & Add** две группы, на каждой отметьте **Inherit from Emitter**. Режим групп **First Group Only** → всё рождается в группе 1. [▶ 2:37](https://youtu.be/yOPa8oM_KXE?t=157)
2. Gravity ▸ Groups Affected = только **группа 2** (пока ничего не падает). [▶ 3:33](https://youtu.be/yOPa8oM_KXE?t=213)
3. **nxQuestion** ▸ вопрос **Neighbors**: дистанция поиска **0.1** (при 0.05 каждая частица считается поверхностной), **less than 30**, variation 7. Сначала протестируйте с action Set Color (жёлтый) — подсветиться должна только внешняя оболочка. [▶ 6:14](https://youtu.be/yOPa8oM_KXE?t=374)
4. Замените action на **Set Group → группа 2**. Проверка идёт каждый кадр, так что оболочка продолжает разъедаться внутрь. [▶ 8:02](https://youtu.be/yOPa8oM_KXE?t=482)
5. Скорость распада = порог соседей: 20 — почти стоит, 30 — медленно, 40 — средне, 50 — быстро.
6. **nxColor** (группа 2): градиент по параметру (Magma), маппинг по направлению Y. [▶ 8:44](https://youtu.be/yOPa8oM_KXE?t=524)
7. **nxTurbulence** (группа 2): strength 30, scale побольше. **Mapping** ▸ слой Speed → Strength турбулентности, диапазон 0–1 m/s, чтобы песчинки, лежащие на полу, перестали дрожать. [▶ 10:07](https://youtu.be/yOPa8oM_KXE?t=607)
8. Дешёвая имитация столкновений между частицами: слой **nxConstraints ▸ Forces** — Attraction 0, Repulsion 20%, Radius 0.05, Falloff Flat, максимум ~5 соседей. Привяжите силу Repulsion к **Speed** (диапазон 0–0.5), чтобы неподвижное ядро не расталкивало. Теперь падающие песчинки скатываются по внешней поверхности, а не проваливаются сквозь неё. [▶ 13:17](https://youtu.be/yOPa8oM_KXE?t=797)

## Подводные камни
- У поверхностных частиц всегда меньше соседей — дистанция поиска должна быть в несколько раз больше радиуса, иначе всё будет считаться поверхностью.
- Настоящие P-P коллизии тоже сработают, но они тяжелее трюка с repulsion по скорости.
