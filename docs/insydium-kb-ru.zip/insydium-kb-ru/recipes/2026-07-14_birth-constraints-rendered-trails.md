# Пружинистая сетка констрейнтов, отрендеренная трейлами (связи nxConstraints Birth + nxTrail в режиме Constraints)

- Источник: Top Tip Tuesday — Birth Constraints — https://www.youtube.com/watch?v=QDBN_Xu_l68 (2026-07-14)
- Хост / поколение: Blender (NeXus for Blender 2026.0) — nxConstraints, nxCollider, nxGravity, nxTrail; Cycles
- Задача: полотно частиц, связанных пружинами, выстреливает в три Сюзанны, а связи рендерятся светящимися линиями.

## Шаги
1. **nxEmitter**: широкий/высокий прямоугольник, **Shot** ~700, Speed 0; Display **Circle Filled**. [▶ 0:33](https://youtu.be/QDBN_Xu_l68?t=33)
2. **nxConstraints** ▸ один слой, связи **Birth** (пружины). Посмотреть можно через Display эмиттера ▸ **Display Constraints**. [▶ 1:19](https://youtu.be/QDBN_Xu_l68?t=79)
3. Три Сюзанны (Shift+D); **nxGravity**; **nxCollider** со всеми тремя, Friction на максимум (частицы прилипают). Speed эмиттера **8**, расширьте примерно до 12, чтобы накрыть их. [▶ 3:58](https://youtu.be/QDBN_Xu_l68?t=238)
4. Break Type по умолчанию **Relative Connected 50%** (рвётся при растяжении на 50%) → поставьте **None**. [▶ 4:45](https://youtu.be/QDBN_Xu_l68?t=285)
5. **Stiffness** задаёт растяжение (~80 — пружинистее); чтобы было жёстче 100%, поднимите **Iterations** (10 = почти жёстко; 1 = по умолчанию, пружинисто). [▶ 5:18](https://youtu.be/QDBN_Xu_l68?t=318)
6. Connection Limit **8** в пределах Radius **0.4 m** (ближайшие соседи); 3 = редко, 20 = плотно. [▶ 6:17](https://youtu.be/QDBN_Xu_l68?t=377)
7. В коллайдер добавлена плоскость пола: немного отскока; без трения = скольжение, с трением = прилипает и отрывается. [▶ 8:19](https://youtu.be/QDBN_Xu_l68?t=499)
8. **nxTrail** ▸ эмиттер ▸ Connections ▸ **Constraints** (вместо траекторий частиц); выключите отображение констрейнтов у эмиттера. [▶ 9:37](https://youtu.be/QDBN_Xu_l68?t=577)
9. Цвет: вкладка Thickness у трейла ▸ Trail Color Mode **Particle Color**; цвет эмиттера **Noise** с градиентом Magma. [▶ 10:25](https://youtu.be/QDBN_Xu_l68?t=625)
10. Рендер: Display трейла **Lines → Splines** (геометрия GN + автоматический материал с атрибутом цвета трейла) → подайте в цвет Emission, strength ~5. Thickness **Set from Value** 0.1 = толстые трубки, **0.001** = тонкие линии (+ вариация). [▶ 13:25](https://youtu.be/QDBN_Xu_l68?t=805)

## Как сейчас (новые инструменты)
В 2026.1 beta **nxPin** закрепляет сетки констрейнтов для ткани/верёвок; GPU-верёвки и ткань анонсированы в следующей бете.
